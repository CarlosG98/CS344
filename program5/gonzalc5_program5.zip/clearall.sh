#!/bin/bash
rm -f enc_client
rm -f enc_server
rm -f dec_client
rm -f dec_server
